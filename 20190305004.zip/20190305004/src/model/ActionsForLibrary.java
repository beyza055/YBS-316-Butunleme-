package model;

public interface ActionsForLibrary {
	
	
	public void takeABook();
	public void giveABook();
		

}
