package model;

public class Author extends User{
	
	String nickname;
	int author_id;
	int total_book_count;
	
	public void sayYourLastReadBook(String lastbookname) {
		System.out.println("The Author is saying the her/his last read book..." + lastbookname);
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public int getTotal_book_count() {
		return total_book_count;
	}

	public void setTotal_book_count(int total_book_count) {
		this.total_book_count = total_book_count;
	}

	public Author(String id, int age, String name, String lastname, String country_code, String nickname, int author_id,
			int total_book_count) {
		super(id, age, name, lastname, country_code);
		this.nickname = nickname;
		this.author_id = author_id;
		this.total_book_count = total_book_count;
	}

	@Override
	public String toString() {
		return "Author [nickname=" + nickname + ", author_id=" + author_id + ", total_book_count=" + total_book_count
				+ ", id=" + id + ", age=" + age + ", name=" + name + ", lastname=" + lastname + ", country_code="
				+ country_code + ", getNickname()=" + getNickname() + ", getAuthor_id()=" + getAuthor_id()
				+ ", getTotal_book_count()=" + getTotal_book_count() + ", getId()=" + getId() + ", getAge()=" + getAge()
				+ ", getName()=" + getName() + ", getLastname()=" + getLastname() + ", getCountry_code()="
				+ getCountry_code() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	
	@Override
	public void takeABook() {
		System.out.println("The Author is taking a book from the library...");
		
	}
	@Override
	public void giveABook() {
		System.out.println("The Author is giving a book from the library...");
		
	}
	 
	

}
