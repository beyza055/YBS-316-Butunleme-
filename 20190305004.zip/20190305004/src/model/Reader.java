package model;

public class Reader extends User {
	
	String favorite_book_name;
	int total_read_book_count;
	int total_borrowed_book_count;
	
	public void sayYourLastReadBook(String lastbookname) {
		System.out.println("The Reader is saying the her/his last read book..." + lastbookname);
	}

	public String getFavorite_book_name() {
		return favorite_book_name;
	}

	public void setFavorite_book_name(String favorite_book_name) {
		this.favorite_book_name = favorite_book_name;
	}

	public int getTotal_read_book_count() {
		return total_read_book_count;
	}

	public void setTotal_read_book_count(int total_read_book_count) {
		this.total_read_book_count = total_read_book_count;
	}

	public int getTotal_borrowed_book_count() {
		return total_borrowed_book_count;
	}

	public void setTotal_borrowed_book_count(int total_borrowed_book_count) {
		this.total_borrowed_book_count = total_borrowed_book_count;
	}

	public Reader(String id, int age, String name, String lastname, String country_code, String favorite_book_name,
		int total_read_book_count, int total_borrowed_book_count) {
		super(id, age, name, lastname, country_code);
		this.favorite_book_name = favorite_book_name;
		this.total_read_book_count = total_read_book_count;
		this.total_borrowed_book_count = total_borrowed_book_count;
	}

	@Override
	public String toString() {
		return "Reader [favorite_book_name=" + favorite_book_name + ", total_read_book_count=" + total_read_book_count
				+ ", total_borrowed_book_count=" + total_borrowed_book_count + ", id=" + id + ", age=" + age + ", name="
				+ name + ", lastname=" + lastname + ", country_code=" + country_code + ", getFavorite_book_name()="
				+ getFavorite_book_name() + ", getTotal_read_book_count()=" + getTotal_read_book_count()
				+ ", getTotal_borrowed_book_count()=" + getTotal_borrowed_book_count() + ", getId()=" + getId()
				+ ", getAge()=" + getAge() + ", getName()=" + getName() + ", getLastname()=" + getLastname()
				+ ", getCountry_code()=" + getCountry_code() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	@Override
	public void takeABook() {
		System.out.println("The Reader is taking a book from the library...");
		
	}
	@Override
	public void giveABook() {
		System.out.println("The Reader is giving a book from the library...");
		
	}
	
	
}
