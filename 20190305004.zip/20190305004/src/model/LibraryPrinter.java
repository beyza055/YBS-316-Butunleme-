package model;

	public class LibraryPrinter<T> {
	    public void print(T object) {
	    	System.out.println("------- LibraryPrinter is working -------");
	    	
	    	if (object instanceof Author)
	    	{
	    		System.out.println("The Author's ID : " + ((Author)object).getId());
	    	}else if (object instanceof Reader) {
	    		System.out.println("The Reader's ID : " + ((Reader)object).getId());
	    	}else if (object instanceof Book) {
	    		System.out.println("The Book's ID : " + ((Book)object).getBook_code());
	    	}else {
	    		
	    		System.out.println("This Object is not supported to print");
	    	}
	    	System.out.println(object.toString());
	    }
	}
