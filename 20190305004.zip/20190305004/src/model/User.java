package model;

public class User implements ActionsForLibrary {
	
	String id;
	int age;
	String name;
	String lastname;
	String country_code;
	
	public void sayYourLastReadBook() { //Polymorphism __--__
		System.out.println("The user is saying the her/his last read book...");
	}
	
	
	@Override
	public void takeABook() {
		System.out.println("The user is taking a book from the library...");
		
	}
	@Override
	public void giveABook() {
		System.out.println("The user is giving a book from the library...");
		
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getCountry_code() {
		return country_code;
	}


	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}


	public User(String id, int age, String name, String lastname, String country_code) {
		super();
		this.id = id;
		this.age = age;
		this.name = name;
		this.lastname = lastname;
		this.country_code = country_code;
	}
	
	
	

}
