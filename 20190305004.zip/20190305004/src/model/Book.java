package model;

public class Book<T> {
	
	T book_code;
	String author_name;
	int stock_number;
	public T getBook_code() {
		return book_code;
	}
	public void setBook_code(T book_code) {
		this.book_code = book_code;
	}
	public String getAuthor_name() {
		return author_name;
	}
	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}
	public int getStock_number() {
		return stock_number;
	}
	public void setStock_number(int stock_number) {
		this.stock_number = stock_number;
	}
	public Book(T book_code, String author_name, int stock_number) {
		super();
		this.book_code = book_code;
		this.author_name = author_name;
		this.stock_number = stock_number;
	}
	@Override
	public String toString() {
		return "Book [book_code=" + book_code + ", author_name=" + author_name + ", stock_number=" + stock_number
				+ ", getBook_code()=" + getBook_code() + ", getAuthor_name()=" + getAuthor_name()
				+ ", getStock_number()=" + getStock_number() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	

}
