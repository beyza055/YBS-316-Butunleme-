package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import model.Author;
import model.Book;
import model.LibraryPrinter;
import model.Reader;
import model.User;

public class LibraryMain {
	public static ArrayList<Object> authorlist = new ArrayList<Object>();
	public static Map<Integer, Object> readerMap = new HashMap<Integer, Object>();
	public static Set<User> userSet = new HashSet<User>();
	public static ArrayList<Book<?>> booklist = new ArrayList<Book<?>>();
	public static void main(String[] args) {
		System.out.println("How many Do you want to insert AUTHOR? Please enter Integer");
		Scanner input_scanner = new Scanner(System.in);
		int how_many = Integer.parseInt(input_scanner.nextLine());
		
		insert_Author(how_many);
		
		print_user_list();
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		
		System.out.println("How many Do you want to insert READER? Please enter Integer");
		
		how_many = Integer.parseInt(input_scanner.nextLine());
		
		insert_Reader(how_many);
		
		print_reader_map(readerMap);
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		System.out.println("How many Do you want to insert BOOK? Please enter Integer");
		
		how_many = Integer.parseInt(input_scanner.nextLine());
		
		insert_Book(how_many);
		
		print_book_list(booklist);

		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		
		
		
		
		
		
		
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		
		LibraryPrinter printerForEverything = new LibraryPrinter();
		
		printerForEverything.print(authorlist.get(0)); // GET FIRST ELEMENT TO PRINT
		printerForEverything.print(         ((Reader)readerMap.get(1))     ); // GET FIRST ELEMENT TO PRINT
		printerForEverything.print(         ((Book)booklist.get(0))     ); // GET FIRST ELEMENT TO PRINT
		
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		System.out.println("------- ADDING USERSET The First Author and The first Reader -------");
		userSet.add(  ((Author)authorlist.get(0))  );
		userSet.add(  ((Reader)readerMap.get(1))   );
		
		// Lambda functions using to access all elements of the SET
		System.out.println("------- Lambda functions using to access all elements of the SET- PRINTIG NAMES -------");
		userSet.forEach(user -> System.out.println(user.getName()));
		
		
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		
		
		
		System.out.println("------- TESTING polymorphism  -------");
		((Author)authorlist.get(0)).takeABook();
		((Reader)readerMap.get(1)).takeABook();
		
		((Author)authorlist.get(0)).giveABook();
		((Reader)readerMap.get(1)).giveABook();
		
		
		((Author)authorlist.get(0)).sayYourLastReadBook("BOOK1");
		((Reader)readerMap.get(1)).sayYourLastReadBook("BOOK37");
		
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------");
		
		
	}
	
	
	private static void print_book_list(ArrayList<Book<?>> booklist) {
		System.out.println("------- PRINT BOOK LIST -------");
		// USING LAMBDA TO FOR LOOP
		booklist.forEach(book -> System.out.println(    
				
				"Book_code : " + book.getBook_code()    
				
				+ " Author_name : " +  book.getAuthor_name()
				
				+ " Stock_number : " +  book.getStock_number()
				
				));
		
	}


	public static void  print_reader_map(Map<Integer, Object> readerMap) {
		System.out.println("------- PRINT READER MAP -------");
		// USING LAMBDA TO FOR LOOP
		readerMap.forEach((key, value) -> 				
				System.out.println(key + ":"+ 
						" Id: " + ((Reader) value).getId() + " - LastName: " + ((Reader) value).getLastname()		
						+ " - Country_code: " + ((Reader) value).getCountry_code()	
						)
				
				);
	
	}
	public static void  print_user_list() {
		System.out.println("------- PRINT USER LIST -------");
		authorlist.forEach(user -> 
		System.out.println(
				" Id: " + ((User) user).getId() + " - LastName: " + ((User) user).getLastname()		
				+ " - Country_code: " + ((User) user).getCountry_code()	
				));
	}
	public static void insert_Book(int how_many) {
		System.out.println("Enter " + how_many +  " Book");		
		
		Scanner input_scanner = new Scanner(System.in);
		
		
		for (int i = 1; i <= how_many; i++) {
			
			
			System.out.println("**************************************Enter values for : " + i + "/" + how_many );
			
			System.out.println("Enter BOOK book_code, author_name, stock_number ");			
			System.out.println("BOOK_CODE : " + i);
			String book_code = String.valueOf(i);
			
			System.out.print("author_name: ");
			String author_name = input_scanner.nextLine();	
			
			System.out.print("stock_number (int) : ");
			int stock_number = Integer.parseInt(input_scanner.nextLine());
			
			
			Book<?> new_book = new Book<String>(book_code, author_name, stock_number);
			
			
			
			
			booklist.add(new_book);
		}
	}
	
	
	public static void  insert_Reader(int how_many) {
		System.out.println("Enter " + how_many +  " Reader");		
		
		Scanner input_scanner = new Scanner(System.in);
		
		
		for (int i = 1; i <= how_many; i++) {
			
			
			System.out.println("**************************************Enter values for : " + i + "/" + how_many );
			
			System.out.println("Enter Author id, age, name, lastname, country_code, nickname, author_id, total_book_count : ");			
			System.out.println("ID : " + i);
			String id = String.valueOf(i);	
			
			System.out.print("AGE (int) : ");
			int age = Integer.parseInt(input_scanner.nextLine());
			
			System.out.print("NAME: ");
			String name = input_scanner.nextLine();
			
			System.out.print("LASTNAME : ");
			String lastname = input_scanner.nextLine();
			
			System.out.print("COUNTRY_CODE : ");
			String country_code = input_scanner.nextLine();
			
			System.out.print("FAVORITE_BOOK_NAME : ");
			String favorite_book_name = input_scanner.nextLine();
			
			System.out.print("total_read_book_count (int) : ");
			int total_read_book_count = Integer.parseInt(input_scanner.nextLine());
			
			System.out.print("total_borrowed_book_count (int) : ");
			int total_borrowed_book_count = Integer.parseInt(input_scanner.nextLine());
			
			Reader new_reader= new Reader(id, age, name, lastname, country_code, favorite_book_name, total_read_book_count, total_borrowed_book_count);
			
			
			
			readerMap.put(i,new_reader);
		}
		
	}
	
	public static void  insert_Author(int how_many) {
		System.out.println("Enter " + how_many +  " Author");		
		
		Scanner input_scanner = new Scanner(System.in);
		
		
		for (int i = 1; i <= how_many; i++) {
			
			
			System.out.println("**************************************Enter values for : " + i + "/" + how_many );
			
			System.out.println("Enter Author id, age, name, lastname, country_code, nickname, author_id, total_book_count : ");			
			System.out.println("ID : " + i);
			String id = String.valueOf(i);	
			
			System.out.print("AGE (int) : ");
			int age = Integer.parseInt(input_scanner.nextLine());
			
			System.out.print("NAME: ");
			String name = input_scanner.nextLine();
			
			System.out.print("LASTNAME : ");
			String lastname = input_scanner.nextLine();
			
			System.out.print("COUNTRY_CODE : ");
			String country_code = input_scanner.nextLine();
			
			System.out.print("NICKNAME : ");
			String nickname = input_scanner.nextLine();
			
			System.out.print("AUTHOR_ID (int) : ");
			int author_id = Integer.parseInt(input_scanner.nextLine());
			
			System.out.print("TOTAL_BOOK_COUNT (int) : ");
			int total_book_count = Integer.parseInt(input_scanner.nextLine());
			
			Author new_author= new Author(id, 
					age, 
					name, 
					lastname, 
					country_code, 
					nickname, 
					author_id, 
					total_book_count);
			
			
			authorlist.add(new_author);
		}
		
	}
	

}
